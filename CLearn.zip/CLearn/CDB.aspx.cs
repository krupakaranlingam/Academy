﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.DataVisualization.Charting;

namespace WebApplication1
{
    public partial class CDB : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }

        private void GetChartData(string category)
        {
            string cs = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("sp_ChartData_CDB", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@category", category);
                Series series = ChartCDB.Series["Series1"];
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    series.Points.AddXY("InTraining", rdr["Training"].ToString());
                    series.Points.AddXY("Graduated", rdr["Graduated"].ToString());
                    series.Points.AddXY("Resigned", rdr["Resigned"].ToString());
                }
            }
        }
   

        private void BindData()
        {
            string category = "Overall";
            GetChartData(category);
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter da = new SqlDataAdapter("Select * from tabEmployeeDetails where trainingVertical='CDB'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewCDB.DataSource = ds;
                GridViewCDB.DataBind();
            }
        }


        protected void ImageButtonCDB_Click(object sender, ImageClickEventArgs e)
        {


            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GridViewCDB.AllowPaging = false;
                this.BindData();

                //GridViewacademy.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GridViewCDB.HeaderRow.Cells)
                {
                    cell.BackColor = GridViewCDB.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GridViewCDB.Rows)
                {
                    //row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GridViewCDB.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GridViewCDB.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GridViewCDB.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }


        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
        protected void btnintrainingCDB_Click(object sender, EventArgs e)
        {
            string category = "Training";
            GetChartData(category);
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter da = new SqlDataAdapter("Select * from tabEmployeeDetails where trainingVertical='CDB' and traineeStatus='Intraining'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewCDB.DataSource = ds;
                GridViewCDB.DataBind();
            }
        }

        protected void btngraduatedCDB_Click(object sender, EventArgs e)
        {
            string category = "Graduated";
            GetChartData(category);

            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter da = new SqlDataAdapter("Select * from tabEmployeeDetails where  trainingVertical='CDB' and traineeStatus='Graduated'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewCDB.DataSource = ds;
                GridViewCDB.DataBind();
            }
        }

        protected void btnresignedCDB_Click(object sender, EventArgs e)
        {
            string category = "Resigned";
            GetChartData(category);
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter da = new SqlDataAdapter("Select * from tabEmployeeDetails where  trainingVertical='CDB' and traineeStatus='Resigned'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewCDB.DataSource = ds;
                GridViewCDB.DataBind();
            }
        }

        protected void btnoverallCDB_Click(object sender, EventArgs e)
        {
            BindData();
        }

        protected void GridViewCDB_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            BindData();
            GridViewCDB.PageIndex = e.NewSelectedIndex;
            GridViewCDB.DataBind();
        }

      
    }
}