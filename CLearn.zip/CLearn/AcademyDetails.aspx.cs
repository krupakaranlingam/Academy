﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using System.Text;
using System.Collections;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Web.UI.DataVisualization.Charting;


namespace CLearn
{
    public partial class AcademyDetails : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
           

        }

        private void GetChartData(string category)
        {
            string cs = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("sp_ChartData_Academy", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@category", category);
                Series series = Chart1.Series["Default"];
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                string[] xValues = { "AVM", "CDB", "QEA" };
                int[] yValues = new int[3];
                while(rdr.Read())
                {
                    int i=0;
                    foreach(string s in xValues)
                    {
                        yValues[i] = (Int32)rdr[s];
                        i++;
                    }
                }
               // double[] yValues = {  };
  //string[] xValues = { "AAA", "BBB", "CCC" };
  Chart1.Series["Default"].Points.DataBindXY(xValues, yValues);
  
 
  Chart1.Series["Default"].ChartType = SeriesChartType.Pie;
  Chart1.Series["Default"]["PieLabelStyle"] = "Visible";
  Chart1.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
  Chart1.Legends[0].Enabled = true;
                // Chart1.Series["series"].IsValueShownAsLabel = true;
              //  string a = "AVM";
               //string b = "CDB";
              // string c = "QEA";
              
            //  string[] ser = new string[] { "Series1", "Series2", "Series2" };
             
            /*    while (rdr.Read() )
                {
                  //  series.Points.AddXY( "AVM".ToString(),rdr["AVM"].ToString()+"AVM" );

               
               
                  // series.Points.AddXY(a.ToString(), rdr[a].ToString());
                  // series.Label = "AVM" + rdr[a].ToString();
                  // series.Points.AddXY(b.ToString() ,rdr[b].ToString());
                  // series.Label = "CDB" + rdr[b].ToString();
                  // series.Points.AddXY(c.ToString() ,rdr[c].ToString());
                     //series.Label = "AVM" + rdr[a].ToString();
                    // series.Label = "CDB" + rdr[b].ToString();
                   // series.Label = "QEA" +"    " +rdr[c].ToString()+'%';
                   
                    Chart1.Series["Series1"].Points.AddXY("AVM", rdr["AVM"].ToString());
                    Chart1.Series["Series1"].Label = "AVM" + "    " + rdr["AVM"].ToString() + '%';
                    string[] str = new string[]{"AVM","CDB","QEA"};
                    foreach (string s in str)
                    {


                        Chart1.Series["Series1"].Points.AddXY(s, rdr[s].ToString());
                        Chart1.Series["Series1"].Label = s + "    " + rdr[s].ToString() + '%';
                    }

                   // Chart1.Series["Default"].Points[0].Color = Color.MediumSeaGreen;
                    //Chart1.Series["Default"].Points[1].Color = Color.PaleGreen;
                   // Chart1.Series["Default"].Points[2].Color = Color.LawnGreen;

                    Chart1.Series["Series1"].ChartType = SeriesChartType.Pie;
                    Chart1.Series["Series1"]["PieLabelStyle"] = "Visible";
                    Chart1.ChartAreas["ChartArea1"].Area3DStyle.Enable3D = true;
                   Chart1.Legends[0].Enabled = true;
             * */
                  
                
                       
                   

            }
        }
   

        private void BindData()
        {
            string category = "Overall";
            GetChartData(category);
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter da = new SqlDataAdapter("spOverall_Academy_EmployeeDetails", con);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewacademy.DataSource = ds;
                GridViewacademy.DataBind();
            }
        }

        //public override void VerifyRenderingInServerForm(Control control)
        //{
        //}

        protected void ImageButton1_Click(object sender, ImageClickEventArgs e)
        {
            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GridViewacademy.AllowPaging = false;
                this.BindData();

                //GridViewacademy.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GridViewacademy.HeaderRow.Cells)
                {
                    cell.BackColor = GridViewacademy.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GridViewacademy.Rows)
                {
                    //row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GridViewacademy.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GridViewacademy.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GridViewacademy.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }


        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }




        protected void btnintrainingacademy_Click(object sender, EventArgs e)
        {
            string category = "Training";
            GetChartData(category);

            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter da = new SqlDataAdapter("spIntraining_Academy_EmployeeDetails", con);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewacademy.DataSource = ds;
                GridViewacademy.DataBind();
            }
        }


        protected void btngraduatedacademy_Click(object sender, EventArgs e)
        {
            string category = "Graduated";
         
            GetChartData(category);

            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter da = new SqlDataAdapter("spGraduated_Academy_EmployeeDetails", con);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewacademy.DataSource = ds;
                GridViewacademy.DataBind();
            }
        }

        protected void btnresignedacademy_Click(object sender, EventArgs e)
        {
            string category = "Resigned";
         
            GetChartData(category);
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter da = new SqlDataAdapter("spResigned_Academy_EmployeeDetails", con);
                da.SelectCommand.CommandType = CommandType.StoredProcedure;


                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewacademy.DataSource = ds;
                GridViewacademy.DataBind();
            }
        }



        protected void GridViewacademy_PageIndexChanging1(object sender, GridViewPageEventArgs e)
        {
            BindData();
            GridViewacademy.PageIndex = e.NewPageIndex;
            GridViewacademy.DataBind();
        }

        protected void btnoverallacademy_Click(object sender, EventArgs e)
        {
           
            BindData();
        }

      /*  private void GetChartData1(string category)
        {
            string cs = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("sp_ChartData_Academy", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@category", category);
                Series series = Chart2.Series["Series1"];
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    series.Points.AddXY("AVM", rdr["AVM"].ToString());
                    series.Points.AddXY("CDB", rdr["CDB"].ToString());
                    series.Points.AddXY("QEA", rdr["QEA"].ToString());
                    //Chart1.Series["series"].IsValueShownAsLabel = true;
                   


                }
            }*/

        }

        

       



    }

