﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace WebApplication1
{
    public partial class Homepage : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnadmin_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/AcademyDetails.aspx");
        }

        protected void btnuser_Click(object sender, EventArgs e)
        {
            Response.Redirect("~/Admin_BU.aspx");
        }
    }
}