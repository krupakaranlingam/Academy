﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Validation;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace Functions
{
    public class Statements
    {
        public static int AdminLogin(Class1 c)
        {
            string constr = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("spAdminLogin", con);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userId", c.userID);
            cmd.Parameters.AddWithValue("@pass", c.pass);
            cmd.ExecuteNonQuery();
            SqlDataReader reader = cmd.ExecuteReader();
            if ((reader.Read()))
            {
                return 1;

            }
            else
                con.Close();
            return 0;

        }

        public static int BULoginAVM(Class1 c)
        {

            string constr = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("spBULoginAVM", con);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userId", c.buID);
            cmd.Parameters.AddWithValue("@pass", c.bupass);
            cmd.ExecuteNonQuery();
            SqlDataReader reader = cmd.ExecuteReader();

            if ((reader.Read()))
            {
                return 1;
            }
            con.Close();
            return 0;

        }

        public static int BULoginCDB(Class1 c)
        {

            string constr = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("spBULoginCDB", con);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userId", c.buID);
            cmd.Parameters.AddWithValue("@pass", c.bupass);
            cmd.ExecuteNonQuery();
            SqlDataReader reader = cmd.ExecuteReader();

            if ((reader.Read()))
            {
                return 2;
            }
            con.Close();
            return 0;


        }


        public static int BULoginQEA(Class1 c)
        {

            string constr = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("spBULoginQEA", con);
            cmd.CommandType = System.Data.CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@userId", c.buID);
            cmd.Parameters.AddWithValue("@pass", c.bupass);
            cmd.ExecuteNonQuery();
            SqlDataReader reader = cmd.ExecuteReader();

            if ((reader.Read()))
            {
                return 3;
            }
            con.Close();
            return 0;


        }

        public static int MainAdminLogin(Class1 c)
        {
            string constr = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(constr))
            {
                con.Open();
                SqlCommand cmd = new SqlCommand("spMainAdminLogin_New", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@MainAdminID", c.MainAdminID);
                cmd.Parameters.AddWithValue("@MainAdminpass", c.MainAdminpass);
                cmd.ExecuteNonQuery();
                SqlDataReader rdr = cmd.ExecuteReader();
                if ((rdr.Read()))
                {
                    int RetryAttempts = Convert.ToInt32(rdr["RetryAttempts"]);
                    string returnValue = rdr["BU"].ToString();
                    if (Convert.ToBoolean(rdr["AccountLocked"]))
                    {
                        return 99;
                    }
                    else if (RetryAttempts > 0)
                    {
                        int AttemptsLeft = (4 - RetryAttempts);
                        return 98;
                    }
                    else if (Convert.ToBoolean(rdr["Authenticated"]) && (returnValue == "Main Admin"))
                    {
                        return 1;
                    }
                     else if (Convert.ToBoolean(rdr["Authenticated"]) && (returnValue == "Academy"))
                    {
                        return 2;
                    }
                    else if (Convert.ToBoolean(rdr["Authenticated"]) && (returnValue == "AVM"))
                    {
                        return 3;
                    }
                    else if (Convert.ToBoolean(rdr["Authenticated"]) && (returnValue == "CDB"))
                    {
                        return 4;
                    }
                    else if (Convert.ToBoolean(rdr["Authenticated"]) && (returnValue == "QEA"))
                    {
                        return 5;
                    }
                    else return 0;
                }
                else return 0;
            }}}}
                    
                   
                 