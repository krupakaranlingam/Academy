﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Validation;
using Functions;

namespace CLearn
{
    public partial class AdminHome : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnHomeAdmin_Click(object sender, EventArgs e)
        {
            Response.Redirect("AcademyDetails.aspx");
        }

        protected void btnHomeBU_Click(object sender, EventArgs e)
        {
            Response.Redirect("Admin_BU.aspx");
        }
    }
}