﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.DataVisualization.Charting;

namespace WebApplication1
{
    public partial class QEA : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                BindData();
            }
        }

        private void GetChartData(string category)
        {
            string cs = ConfigurationManager.ConnectionStrings["dbconstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(cs))
            {
                SqlCommand cmd = new SqlCommand("sp_ChartData_QEA", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@category", category);
                Series series = ChartQEA.Series["Series1"];
                con.Open();
                SqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    series.Points.AddXY("InTraining", rdr["Training"].ToString());
                    series.Points.AddXY("Graduated", rdr["Graduated"].ToString());
                    series.Points.AddXY("Resigned", rdr["Resigned"].ToString());
                }
            }
        }
   

        private void BindData()
        {
            string category = "Overall";
            GetChartData(category);
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter da = new SqlDataAdapter("Select * from tabEmployeeDetails where trainingVertical='QEA'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewQEA.DataSource = ds;
                GridViewQEA.DataBind();
            }
        }


        protected void ImageButtonQEA_Click(object sender, ImageClickEventArgs e)
        {

            Response.Clear();
            Response.Buffer = true;
            Response.AddHeader("content-disposition", "attachment;filename=GridViewExport.xls");
            Response.Charset = "";
            Response.ContentType = "application/vnd.ms-excel";
            using (StringWriter sw = new StringWriter())
            {
                HtmlTextWriter hw = new HtmlTextWriter(sw);

                //To Export all pages
                GridViewQEA.AllowPaging = false;
                this.BindData();

                //GridViewacademy.HeaderRow.BackColor = Color.White;
                foreach (TableCell cell in GridViewQEA.HeaderRow.Cells)
                {
                    cell.BackColor = GridViewQEA.HeaderStyle.BackColor;
                }
                foreach (GridViewRow row in GridViewQEA.Rows)
                {
                    //row.BackColor = Color.White;
                    foreach (TableCell cell in row.Cells)
                    {
                        if (row.RowIndex % 2 == 0)
                        {
                            cell.BackColor = GridViewQEA.AlternatingRowStyle.BackColor;
                        }
                        else
                        {
                            cell.BackColor = GridViewQEA.RowStyle.BackColor;
                        }
                        cell.CssClass = "textmode";
                    }
                }

                GridViewQEA.RenderControl(hw);

                //style to format numbers to string
                string style = @"<style> .textmode { } </style>";
                Response.Write(style);
                Response.Output.Write(sw.ToString());
                Response.Flush();
                Response.End();
            }
        }


        public override void VerifyRenderingInServerForm(Control control)
        {
            /* Verifies that the control is rendered */
        }
        protected void btnintrainingQEA_Click(object sender, EventArgs e)
        {
            string category = "Training";
            GetChartData(category);
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter da = new SqlDataAdapter("Select * from tabEmployeeDetails where trainingVertical='QEA' and traineeStatus='Intraining'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewQEA.DataSource = ds;
                GridViewQEA.DataBind();
            }
        }

        protected void btngraduatedQEA_Click(object sender, EventArgs e)
        {
            string category = "Graduated";
            GetChartData(category);
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter da = new SqlDataAdapter("Select * from tabEmployeeDetails where  trainingVertical='QEA' and traineeStatus='Graduated'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewQEA.DataSource = ds;
                GridViewQEA.DataBind();
            }
        }

        protected void btnresignedQEA_Click(object sender, EventArgs e)
        {
            string category = "Resigned";
            GetChartData(category);
            string CS = ConfigurationManager.ConnectionStrings["dbConstr"].ConnectionString;
            using (SqlConnection con = new SqlConnection(CS))
            {
                SqlDataAdapter da = new SqlDataAdapter("Select * from tabEmployeeDetails where  trainingVertical='QEA' and traineeStatus='Resigned'", con);
                DataSet ds = new DataSet();
                da.Fill(ds);
                GridViewQEA.DataSource = ds;
                GridViewQEA.DataBind();
            }
        }

        protected void btnoverallQEA_Click(object sender, EventArgs e)
        {
            BindData();
        }

        protected void GridViewQEA_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            BindData();
            GridViewQEA.PageIndex = e.NewPageIndex;
            GridViewQEA.DataBind();
        }

        }
    }
