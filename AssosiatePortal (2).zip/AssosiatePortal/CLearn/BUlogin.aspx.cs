﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Validation;
using Functions;

namespace WebApplication1
{
    public partial class BUlogin : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmitbu_Click(object sender, EventArgs e)
        {
            Class1 t = new Class1();
            t.buID = txtbuid.Text;
            t.bupass = txtbupassword.Text;
            lblbulogin.Visible = false;

            if (Statements.BULoginAVM(t) == 1)
            {
                Response.Redirect("~/AVM.aspx");
            }
            else if (Statements.BULoginCDB(t) == 2)
            {
                Response.Redirect("~/CDB.aspx");
            }

            else if (Statements.BULoginQEA(t) == 3)
            {
                Response.Redirect("~/QEA.aspx");
            }

            else
            {
                lblbulogin.Visible = true;
                lblbulogin.Text = "Invalid Credentials";
            }
                
        }
    }
}