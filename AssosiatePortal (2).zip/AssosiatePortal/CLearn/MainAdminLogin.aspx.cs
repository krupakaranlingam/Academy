﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Validation;
using Functions;

namespace CLearn
{
    public partial class MainAdminLogin : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSubmitAdmin_Click(object sender, EventArgs e)
        {
            Class1 t = new Class1();
            t.MainAdminID = txtMainAdminId.Text;
            t.MainAdminpass = txtMainAdminPassword.Text;
            lblMainAdminError.Visible = false;

            if (Statements.MainAdminLogin(t) == 0)
            {
                lblMainAdminError.Visible = true;
                lblMainAdminError.Text = "Invalid Credentials";
            }
            else
            if (Statements.MainAdminLogin(t) == 1)
            {
                Response.Redirect("~/Homepage.aspx");
            }
            else
                if (Statements.MainAdminLogin(t) == 2)
                {
                    Response.Redirect("~/AcademyDetails.aspx");
                }
                else
                    if (Statements.MainAdminLogin(t) == 3)
                    {
                        Response.Redirect("~/AVM.aspx");
                    }
                    else
                        if (Statements.MainAdminLogin(t) == 4)
                        {
                            Response.Redirect("~/CDB.aspx");
                        }
                        else
                           if (Statements.MainAdminLogin(t) == 5)
                            {
                                Response.Redirect("~/QEA.aspx");
                            }
                           else
                               if (Statements.MainAdminLogin(t) == 99)
                               {
                                   lblMainAdminError.Text = "Account locked. Please contact administrator";
                               }
                               else
                                   if (Statements.MainAdminLogin(t) == 98)
                                   {
                                       lblMainAdminError.Text = "Check Credentials Properly.Max attempts 4";
                                   }
                            
            }
        }
    }
